{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "id": "1001"
    ,"poster": "赵"
    ,"avatar": "https://wx4.sinaimg.cn/mw1024/5db11ff4gy1fmx4keaw9pj20dw08caa4.jpg"
    ,"content": "为什么花儿这么么红"
    ,"posttime": 20160805
    ,"top": false
  },{
    "id": "1002"
    ,"poster": "钱"
    ,"avatar": "https://wx4.sinaimg.cn/mw1024/5db11ff4gy1fmx4keaw9pj20dw08caa4.jpg"
    ,"content": "喜欢胡歌，赞赞赞"
    ,"posttime": 20161205
    ,"top": true
  },{
    "id": "1003"
    ,"poster": "孙"
    ,"avatar": "https://wx4.sinaimg.cn/mw1024/5db11ff4gy1fmx4keaw9pj20dw08caa4.jpg"
    ,"content": "明天就要考试了，好紧张，求保佑"
    ,"posttime": 20170405
    ,"top": false
  },{
    "id": "1004"
    ,"poster": "李"
    ,"avatar": "https://wx4.sinaimg.cn/mw1024/5db11ff4gy1fmx4keaw9pj20dw08caa4.jpg"
    ,"content": "希望明天是个好天气" 
    ,"posttime": 20171005
    ,"top": false
  },{
    "id": "1005"
    ,"poster": "周"
    ,"avatar": "https://wx4.sinaimg.cn/mw1024/5db11ff4gy1fmx4keaw9pj20dw08caa4.jpg"
    ,"content": "女追男隔层纱，是不是真的"
    ,"posttime": 20180205
    ,"top": false
  },{
    "id": "1006"
    ,"poster": "吴"
    ,"avatar": "https://wx4.sinaimg.cn/mw1024/5db11ff4gy1fmx4keaw9pj20dw08caa4.jpg"
    ,"content": "竟然有人跳楼，年轻人想不开啊！" 
    ,"posttime": 20180512
    ,"top": false
  },{
    "id": "1007"
    ,"poster": "郑"
    ,"avatar": "https://wx4.sinaimg.cn/mw1024/5db11ff4gy1fmx4keaw9pj20dw08caa4.jpg"
    ,"content": "大家一定不能学那个年轻人，珍爱生命啊"
    ,"posttime": 20180512
    ,"top": false
  },{
    "id": "1008"
    ,"poster": "王"
    ,"avatar": "https://wx4.sinaimg.cn/mw1024/5db11ff4gy1fmx4keaw9pj20dw08caa4.jpg"
    ,"content": "想知道南昌哪里有好吃的西安肉夹馍"
    ,"posttime": 20180514
    ,"top": false
  }]
}